# Runbook

## Health at a glance
- Dashboard header: "live" pill and the tick advancing every 10 s.
- `GET :8082/api/propagation/status` → `catalogSize` ≈ 16.5k, `lastTick` recent, `lastTickObjects` ≈ catalogSize.
- `GET :8083/api/analytics/status` → `state: RUNNING`.
- `GET :8081/api/ingest/status` → last run has `error: null`; `fromCache` tells you whether the provider was hit.
- Kafka UI (`:8090`) → consumer group `orbitwatch-analytics` lag near zero on `state-vectors`.

## Alarms that already exist — check them on every review
| Signal | Where | Meaning |
|---|---|---|
| `orbitwatch_ingest_gp_fetch_failures_total` rising | Prometheus / ingest log `fetch failed` | Provider unreachable; running on cache |
| Ingest run with `error` | `ow.ops.ingest-runs.v1`, dashboard "Ingest runs" | Parse or publish failure — inspect ingest log |
| `PROPAGATION_FAILURE` alerts | alerts topic, dashboard | Objects that decayed / bad elements; a sudden burst means a bad feed |
| `Skipping record for expired window` WARN | analytics log | Analytics falling behind (lag) — see "Analytics lag" |
| `previous tick still running; skipping` WARN | propagation log | Tick slower than interval — CPU starved or Kafka slow |
| `orbitwatch_propagation_last_tick_objects` ≪ `catalog_size` | Prometheus | Many propagation failures |

## Common situations
**No data on the dashboard after start.** Order of readiness is ingest → propagation → analytics
(stats appear ~20 s after the first tick) → gateway. Check the ingest log for the first run line;
check `propagation/status` for `catalogSize`.

**Analytics lag / expired windows.** After a restart with a backlog this is expected while
catching up (threads run at different speeds). If it persists in steady state: increase
`num.stream.threads`, increase `window-grace`, or add a second analytics instance (partitions
rebalance automatically).

**Provider blocked / rate limited.** Never reduce `min-interval` below PT2H. Use replay mode
(`INGEST_GP_REPLAY_FILE`) for demos and load tests.

**Reset analytics state** (e.g. after changing the topology):
`kafka-streams-application-reset.sh --application-id orbitwatch-analytics --input-topics ow.telemetry.state-vectors.v1,ow.catalog.gp-elements.v1 --to-latest`
with the service stopped, then delete its state dir.

**Kafka disk.** State vectors retain 1 h (~600 MB/h compressed at 10 s ticks). Adjust in `TopicSpecs`.

## Local operations
- Start: `docker compose up -d kafka kafka-ui && scripts/run-local.sh [--offline]`; logs in `/tmp/orbitwatch`.
- Stop: `scripts/stop-local.sh`; `docker compose down -v` wipes Kafka data.
- Force an ingest run: `curl -X POST :8081/api/ingest/run`.
