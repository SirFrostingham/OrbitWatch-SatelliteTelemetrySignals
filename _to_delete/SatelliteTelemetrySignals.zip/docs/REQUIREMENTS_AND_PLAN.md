# Requirements and plan

Living document. Requirements are recorded as stated; status is kept current.

## Requirements (as stated, 2026-09-10)

| # | Requirement | Status |
|---|---|---|
| R1 | Demo application relating to the space / SDA industry, built in free time, to bring to a Slingshot Aerospace Engineering Manager technical deep dive | Done — OrbitWatch |
| R2 | Containerized | Done — one multi-stage `Dockerfile` for all services, `docker-compose.yml` |
| R3 | Deployable to a cloud such as OCI | Done — Terraform single-VM (Ampere A1) + OKE kustomize + OCI Streaming overlay + OCIR push script |
| R4 | Java + Spring Boot + Kafka, plus related JD technologies | Done — Spring Boot 3.5 / Java 21, Kafka + Kafka Streams, GraphQL, TypeScript/React, REST/OpenAPI, SSE. Kotlin: planned (next service) |
| R5 | Server(s) and a way for a client to connect and derive interesting data | Done — four services; browser dashboard, REST, GraphQL (query + subscription), SSE; `curl`-able |
| R6 | Explainable in system-design terms | Done — `docs/ARCHITECTURE.md`, `docs/adr/*`, `docs/INTERVIEW_TALKING_POINTS.md`, diagrams |
| R7 | Not limited to NORAD data; CelesTrak GP JSON as a starting point | Done for GP + SATCAT; ingest is source-pluggable (`groups`, replay files); other sources listed in `docs/PROJECT_IDEAS.md` |
| R8 | Source lives at `E:\source\Research\SatelliteTelemetrySignals` | Done |
| R9 | Take the implementation as far as possible | Done to a running, tested, documented end-to-end system (see "What is verified") |

## What is verified

- `mvn verify`: 113 tests green across contracts (5), astro-core (82, incl. 65 reference-vector
  cases), ingest (8), propagation (5), analytics (7, TopologyTestDriver), gateway (6, incl.
  GraphQL schema wiring).
- End to end on a 2-core sandbox with Kafka in Docker: 16,506 objects ingested, propagated every
  10 s (tick ≈ 0.8 s), tick statistics emitted every tick, conjunction / decay / stale alerts
  flowing, dashboard rendering with live SSE, ground tracks, GraphQL and Swagger reachable.
- Restart behaviour: ingest warm restart republishes 0; propagation reloads the catalogue from the
  compacted topic; gateway rebuilds views.
- `docker compose config` valid; Terraform HCL parses; Kubernetes YAML parses. Not run in the
  sandbox (no daemon-side network / no OCI tenancy): the Docker image build itself and the OCI
  apply. Both are exercised by CI / by you on first use — see "Next".

## Next (in order)

1. **First run on your machine**: `docker compose up --build`; confirm the image build (the only
   step not executed in the sandbox) and open the dashboard. If the build stage is slow, run
   `mvn -DskipTests package` + `scripts/run-local.sh` instead.
2. **Push to GitHub** (`sirfrostingham/SatelliteTelemetrySignals`) so the CI workflow and the
   Terraform `repo_url` default become real. Before the first push: `data/` holds two ~7 MB
   snapshots (fine, well under GitHub's 100 MB cap); no secrets are tracked; the `.gitignore`
   excludes the built dashboard, `target/`, caches and Terraform state.
3. **OCI**: copy `deploy/oci/terraform/orbitwatch.tfvars.example` → `orbitwatch.tfvars`, fill in,
   `terraform apply`. Ampere A1 4 OCPU / 24 GB is Always-Free eligible where capacity allows.
4. **Kotlin service** to cover the JD: a small `cli-client` (Kotlin + GraphQL WebSocket
   subscription printing alerts) or port `analytics-service` — ~1 day.
5. **Durable alerts**: Postgres sink for alerts with acknowledge/resolve, and a history endpoint.
6. **Refined conjunction assessment**: for screened pairs, propagate both at 1 s over ±10 min to
   find TCA and miss distance; fold element-set age into a confidence.
7. **Second source**: Space-Track GP (authenticated, shows credential handling and rate limits)
   or an ADS-B feed to demonstrate that the ingest pattern generalises.

## Decisions log

See `docs/adr/`. Notable calibrations made during verification: GEO band tightened to ±0.5 % of a
sidereal day (graveyard orbits were classified GEO); decay-watch B* rule raised to 5×10⁻³ with
perigee < 300 km (Starlink insertion orbits produced ~530 false positives); pairs under 10 m
treated as one physical object (ISS + docked vehicles); tick statistics moved to two-stage
aggregation (hot key); window grace 5 s.
