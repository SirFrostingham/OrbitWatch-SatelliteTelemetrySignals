package com.orbitwatch.ingest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.orbitwatch.contracts.GpElementSet;
import com.orbitwatch.contracts.IngestRun;
import com.orbitwatch.contracts.Topics;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.ArgumentCaptor;

class GpIngestServiceTest {

    @TempDir Path tmp;

    private GpIngestService build(KafkaPublisher publisher, ElementChangeDetector detector) throws Exception {
        Path replay = tmp.resolve("gp.json");
        try (var in = getClass().getResourceAsStream("/gp-sample.json")) { Files.copy(in, replay); }
        IngestProperties props = new IngestProperties(
                new IngestProperties.Gp("https://example.invalid/gp.php", List.of("active"), Duration.ofHours(2), replay.toString()),
                new IngestProperties.Satcat(false, "https://example.invalid/satcat.csv", Duration.ofHours(24), null),
                tmp.resolve("cache").toString());
        return new GpIngestService(props, new CelestrakClient(), new SourceCache(tmp.resolve("cache")), detector, publisher, new SimpleMeterRegistry());
    }

    @Test
    void coldStartPublishesEverythingButNoNewObjectAlerts() throws Exception {
        KafkaPublisher publisher = mock(KafkaPublisher.class);
        when(publisher.send(anyString(), anyString(), any())).thenReturn(CompletableFuture.completedFuture(null));
        when(publisher.sendAll(anyString(), any())).thenReturn(0);
        ElementChangeDetector detector = new ElementChangeDetector();
        GpIngestService svc = build(publisher, detector);
        svc.markWarmed();

        IngestRun run = svc.runOnce();

        assertThat(run.error()).isNull();
        assertThat(run.fetched()).isEqualTo(300);
        assertThat(run.published()).isEqualTo(300);
        assertThat(run.newObjects()).isEqualTo(300);
        assertThat(run.fromCache()).isTrue();
        assertThat(detector.size()).isEqualTo(300);
        verify(publisher, never()).sendAll(eq(Topics.ALERTS), any());
    }

    @Test
    void secondRunWithSameDataPublishesNothing() throws Exception {
        KafkaPublisher publisher = mock(KafkaPublisher.class);
        when(publisher.send(anyString(), anyString(), any())).thenReturn(CompletableFuture.completedFuture(null));
        when(publisher.sendAll(anyString(), any())).thenReturn(0);
        ElementChangeDetector detector = new ElementChangeDetector();
        GpIngestService svc = build(publisher, detector);
        svc.markWarmed();
        svc.runOnce();

        IngestRun second = svc.runOnce();

        assertThat(second.published()).isZero();
        assertThat(second.unchanged()).isEqualTo(300);
        assertThat(second.newObjects()).isZero();
    }

    @Test
    void warmedDetectorEmitsNewObjectAlertsForUnknownIds() throws Exception {
        KafkaPublisher publisher = mock(KafkaPublisher.class);
        when(publisher.send(anyString(), anyString(), any())).thenReturn(CompletableFuture.completedFuture(null));
        when(publisher.sendAll(anyString(), any())).thenReturn(0);
        ElementChangeDetector detector = new ElementChangeDetector();
        // pretend Kafka already knew about 299 of the 300 objects (all but NORAD 900)
        List<GpElementSet> known;
        try (var in = getClass().getResourceAsStream("/gp-sample.json")) {
            known = GpJsonParser.parse(in, "x", java.time.Instant.EPOCH);
        }
        known.stream().filter(e -> e.noradId() != 900).forEach(detector::remember);
        GpIngestService svc = build(publisher, detector);
        svc.markWarmed();

        IngestRun run = svc.runOnce();

        assertThat(run.newObjects()).isEqualTo(1);
        assertThat(run.published()).isEqualTo(1);
        @SuppressWarnings("unchecked")
        ArgumentCaptor<List<KafkaPublisher.KeyedRecord>> captor = ArgumentCaptor.forClass(List.class);
        verify(publisher).sendAll(eq(Topics.ALERTS), captor.capture());
        assertThat(captor.getValue()).hasSize(1);
        assertThat(captor.getValue().get(0).key()).isEqualTo("new:900");
    }
}
