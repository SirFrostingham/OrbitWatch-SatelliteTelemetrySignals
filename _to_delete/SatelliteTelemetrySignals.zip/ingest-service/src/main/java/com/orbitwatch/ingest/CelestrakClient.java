package com.orbitwatch.ingest;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.zip.GZIPInputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Thin HTTP client for CelesTrak. Identifies itself (providers ask for that), accepts gzip, and
 * treats anything but 200 as a fetch failure — the caller decides whether to serve from cache.
 */
@Component
public class CelestrakClient {
    private static final Logger log = LoggerFactory.getLogger(CelestrakClient.class);
    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();

    public static final class FetchException extends IOException {
        public FetchException(String msg, Throwable cause) { super(msg, cause); }
        public FetchException(String msg) { super(msg); }
    }

    public InputStream fetch(String url) throws FetchException {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(120))
                .header("User-Agent", "OrbitWatch/0.1 (+https://github.com/sirfrostingham/SatelliteTelemetrySignals)")
                .header("Accept-Encoding", "gzip")
                .GET().build();
        try {
            long t0 = System.nanoTime();
            HttpResponse<byte[]> resp = http.send(req, HttpResponse.BodyHandlers.ofByteArray());
            if (resp.statusCode() != 200) {
                throw new FetchException("GET " + url + " -> HTTP " + resp.statusCode());
            }
            byte[] body = resp.body();
            log.info("fetched {} bytes from {} in {} ms", body.length, url, (System.nanoTime() - t0) / 1_000_000);
            boolean gz = resp.headers().firstValue("Content-Encoding").map(v -> v.contains("gzip")).orElse(false);
            InputStream in = new ByteArrayInputStream(body);
            return gz ? new GZIPInputStream(in) : in;
        } catch (IOException e) {
            throw new FetchException("GET " + url + " failed: " + e.getMessage(), e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new FetchException("interrupted", e);
        }
    }
}
