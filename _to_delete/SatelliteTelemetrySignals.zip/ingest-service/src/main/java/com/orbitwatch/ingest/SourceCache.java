package com.orbitwatch.ingest;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.time.Instant;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * On-disk cache of the last raw payload per source. Purpose: (1) be a good citizen — never
 * re-fetch inside the provider's minimum interval, even across restarts; (2) keep the pipeline
 * alive when the provider is unreachable (serve stale with a flag rather than fail closed).
 */
public final class SourceCache {
    private static final Logger log = LoggerFactory.getLogger(SourceCache.class);
    private final Path dir;

    public SourceCache(Path dir) throws IOException {
        this.dir = dir;
        Files.createDirectories(dir);
    }

    public record Entry(Path path, Instant fetchedAt) {
        public boolean isFresh(Duration maxAge) { return fetchedAt.plus(maxAge).isAfter(Instant.now()); }
        public InputStream open() throws IOException { return Files.newInputStream(path); }
    }

    public Optional<Entry> get(String key) {
        Path p = dir.resolve(safe(key));
        if (!Files.exists(p)) return Optional.empty();
        try {
            return Optional.of(new Entry(p, Files.getLastModifiedTime(p).toInstant()));
        } catch (IOException e) {
            return Optional.empty();
        }
    }

    public Entry put(String key, InputStream data) throws IOException {
        Path p = dir.resolve(safe(key));
        Path tmp = dir.resolve(safe(key) + ".tmp");
        Files.copy(data, tmp, StandardCopyOption.REPLACE_EXISTING);
        Files.move(tmp, p, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        log.info("cached {} ({} bytes)", key, Files.size(p));
        return new Entry(p, Instant.now());
    }

    private static String safe(String key) {
        return key.replaceAll("[^A-Za-z0-9._-]", "_");
    }
}
