# OrbitWatch architecture

This document is written to be walked through in a technical design review. Each section names the
decision, the alternative that was rejected, and the consequence you can observe in the running
system.

## 1. The problem shape

The input is a bulk, slowly changing catalogue (about 16,500 element sets, each re-fitted by the
18th Space Defense Squadron a few times a day) published as a single JSON document. The output
operators want is the opposite shape: a continuous, per-object stream of "where is it now",
aggregated into fleet-level situational awareness and a small number of actionable alerts. The
whole architecture is the transformation from "one big document every two hours" to "16,500
keyed events every ten seconds, plus derived facts" — and that transformation is exactly what
Kafka is for.

```
 bulk pull (2 h)   →   keyed change stream   →   fan-out compute (10 s)   →   windowed analytics   →   materialised views
   ingest               gp-elements topic          propagation                   Kafka Streams            gateway
```

## 2. Services

| Service | Port | Responsibility | State |
|---|---|---|---|
| ingest-service | 8081 | Only component that talks to the outside world. Fetch, cache, parse, fingerprint, diff, publish. Emits `NEW_OBJECT` alerts. | Fingerprint map, warmed from Kafka on start |
| propagation-service | 8082 | Materialises the two compacted catalogue topics in memory; every tick propagates every object with SGP4 and emits a `StateVectorEvent`. Serves on-demand ground tracks. | Catalogue in memory, rebuilt from Kafka on start |
| analytics-service | 8083 | Kafka Streams topology: per-tick statistics, spatially partitioned conjunction screening, decay watch, stale elements, manoeuvre candidates, alert de-duplication. | Kafka-backed state stores (RocksDB + changelog topics) |
| gateway-service | 8080 | The only thing clients talk to. Materialises bounded views (latest vector per object, recent stats, recent alerts) and exposes REST, GraphQL, SSE; serves the dashboard; proxies ground tracks to propagation. | Bounded in-memory views, rebuilt on start |

Every service is stateless across restarts in the sense that matters: Kafka is the system of record
and each service can rebuild what it needs from the topics. There is no database. That is a
deliberate scope decision (see ADR-0005) — a durable alert store and historical queries are the
first thing to add for a product.

## 3. Topics are the contract

All topic names, partition counts, retention and compaction policies live in one module,
`contracts`, next to the JSON record types. A team that produces to a topic owns its provisioning
(`TopicSpecs`), and a consumer team gets the record type from the same artifact. This is the
"clear API contracts and data exchange patterns" idea applied to an event-driven system: the
contract is code, versioned, and unit-tested for round-trip and forward compatibility.

| Topic | Key | Semantics | Partitions / policy | Producer → consumers |
|---|---|---|---|---|
| `ow.catalog.gp-elements.v1` | NORAD id | Latest element set per object — a **table** | 6 / compacted | ingest → propagation, analytics |
| `ow.catalog.objects.v1` | NORAD id | SATCAT metadata (owner, type, launch) — a table | 6 / compacted | ingest → propagation |
| `ow.telemetry.state-vectors.v1` | NORAD id | One position/velocity per object per tick — a **stream** | 6 / 1 h retention | propagation → analytics, gateway |
| `ow.analytics.tick-stats.v1` | tick | Fleet statistics per tick | 1 / 24 h | analytics → gateway |
| `ow.analytics.alerts.v1` | alert id | Operator alerts | 6 / 7 d | analytics, ingest, propagation → gateway |
| `ow.ops.ingest-runs.v1` | run id | Ingest observability | 1 / 7 d | ingest → gateway |

Versioning rule: additive optional fields never bump the version (the shared `ObjectMapper`
ignores unknown properties, so old consumers tolerate new producers); a breaking change is a new
`.v2` topic with a bridge, never an in-place mutation. Keys are NORAD ids so that all events for
one object land on one partition — ordering per object is guaranteed, and consumers can shard by
partition.

Payloads are JSON, not Avro/Protobuf (ADR-0002): readable in Kafka UI during a demo, zero schema
registry to operate, and the contract module plus tests gives the compatibility discipline. The
cost is bytes (state vectors are ~450 B each, ~750 kB per tick before lz4) and the lack of a
registry-enforced schema — the trade-off flips at higher volume or with external consumers.

## 4. Ingest: bulk pull → change stream

1. **Fetch** `gp.php?GROUP=active&FORMAT=json` (one HTTP call, ~7 MB gzipped to ~1 MB) through a
   cache that refuses to hit the provider inside its published 2-hour minimum interval — across
   restarts, because the cache is on disk. If the provider is down the last payload is served with
   `fromCache=true`; the pipeline degrades to "slightly stale" rather than empty.
2. **Fingerprint** each element set over its orbit-defining fields only (epoch, mean elements,
   B*, element-set number) — not the name, not the ingest time — so a re-fetch of unchanged data
   is recognised as unchanged.
3. **Diff** against the last published fingerprint per object. On start the map is rebuilt by
   reading the compacted topic to its end (`CompactedTopicLoader`); a restart republishes nothing.
4. **Publish** only NEW/CHANGED sets, keyed by NORAD id, `acks=all`, idempotent producer.
5. **Alert** `NEW_OBJECT` for ids never seen before — but only once the detector is warm, so a
   cold start is not 16,500 alerts.

Observed: first run publishes 16,506; every subsequent run inside the provider window publishes 0
("unchanged=16506"); a run after CelesTrak updates publishes the few hundred re-fitted sets.

SATCAT (70k rows including everything that ever decayed) is joined down to the ~16.5k objects that
have elements and published to the compacted catalogue topic only when a row's content changes.

## 5. Propagation: table + tick

The propagation service consumes both compacted topics with a **unique consumer group per
instance** and `auto.offset.reset=earliest`. On a compacted topic that is exactly "load the table,
then follow changes" — no snapshot/CDC machinery, and a second instance loads its own copy.

Every 10 s the ticker computes an **aligned tick** (`floor(now / 10 s)`), propagates every object
to that instant with SGP4 in a parallel stream, converts TEME → ECEF → WGS-84 geodetic, and
publishes one `StateVectorEvent` per object with the catalogue fields denormalised (name, owner,
type, regime) so no downstream consumer needs a join. Aligning ticks to wall-clock multiples
means every instance and every restart produces vectors for identical instants: the analytics
windows key on the tick, and a standby instance produces duplicates rather than skew.

Cost: 16.5k SGP4 evaluations take ~40 ms of CPU; producing 16.5k records takes the rest. The
measured tick is ~0.8 s on two shared cores (`orbitwatch_propagation_tick_seconds`). Scaling is by
partitioning the catalogue (e.g. by NORAD id modulo N instances) — the aligned-tick design makes
the outputs of N instances indistinguishable from one.

Objects that fail to propagate (decayed, non-physical elements) are marked failed once, emit one
`PROPAGATION_FAILURE` alert, and are skipped until a new element set arrives.

### SGP4 without a library

`astro-core` contains a line-for-line Java port of Vallado's reference SGP4/SDP4 (the 2006 AIAA
paper with all later `sgp4fix` corrections), including the deep-space branch for periods ≥ 225
min (GEO, Molniya, GPS). It is validated in `Sgp4ReferenceTest` against the reference C++ (via the
Python `sgp4` package) on 63 live objects across every regime at nine time offsets from −5 h to
+7 days: agreement is within 1 m / 1 mm·s⁻¹ (floating-point noise). The alternative, Orekit, is the
industry-grade choice but pulls in a 30 MB data bundle and a large API for a demo that needs one
function. The port is ~700 lines and allocation-free in the hot path.

Accuracy caveat that matters for the analytics: GP element sets propagated with SGP4 are good to
~1 km at epoch, degrading to several km per day. Everything downstream that compares positions is
a *screen*, not a determination.

## 6. Analytics: Kafka Streams

```
state-vectors ──┬─► per-partition partial TickAccumulator ─► repartition(1) ─► merge ─► tick-stats
                ├─► flatMap ghost cells ─► window(tick) per cell ─► CellBucket ─► suppress ─► pair screen ─┐
                └─► filter stale ────────────────────────────────────────────────────────────────────────┤
gp-elements ────┬─► DecayWatch ───────────────────────────────────────────────────────────────────────────┤
                └─► ManeuverDetector (store: last element set per object) ────────────────────────────────┤
                                                                                  AlertDeduper (store) ◄──┘
                                                                                            │
                                                                                          alerts
```

Event time is the tick (custom `TimestampExtractor`), so windows align to ticks regardless of
publish latency.

**Per-tick statistics — a hot-key story.** The obvious topology (`groupBy(tick)` → windowed
aggregate) funnels 16.5k records per tick through one key, one partition and one thread, with a
state-store read-modify-write per record. It fell 100k records behind on the demo box. The fix is
the standard two-stage aggregation: a processor on every source partition folds vectors into an
in-memory accumulator per tick (no serialisation per record) and flushes one partial per tick on a
wall-clock punctuation; a second processor on a single-partition repartition topic merges the
handful of partials and emits once. The accumulators are in-memory only — an explicit "derived
data, cheap to recompute, at-least-once" choice — and the merge stage records ticks it has
published so a straggler partial is dropped, never double-counted.

**Conjunction screening — partition by space.** All-vs-all distance checks are O(N²): 136 M pairs
per tick at 16.5k objects. `ConjunctionScreener` buckets positions into 50 km cubes and only
compares neighbours (exact when the cell side ≥ threshold). In Streams the cell index becomes the
message key: each vector is published to its own cell and to any adjacent cell within the 10 km
threshold ("ghost" copies, typically 1–4 keys), cells are windowed per tick, and when a window
closes the bucket (a handful of objects) is screened locally. A pair is reported exactly once —
in the own cell of the lower NORAD id. That turns a global O(N²) problem into embarrassingly
parallel per-partition work; `ConjunctionScreenerTest` proves the grid screen equals brute force
and that ghosting never loses a pair. Observed results are physically real: TerraSAR-X/TanDEM-X
(~0.5 km formation), Tianhui 5A/5B, PIESAT, MEV-2 docked to Intelsat 10-02, ONEWEB and Starlink
train neighbours. Pairs under 10 m are docked vehicles catalogued under one element set (the ISS
and its visiting spacecraft) and are filtered as one physical object.

**Alert rules** (all thresholds in `application.yml`):

| Alert | Source | Rule | Severity |
|---|---|---|---|
| CONJUNCTION | state vectors | pair distance < 10 km at a tick (0.01 km floor) | < 1 km critical, < 5 km warning, else info |
| DECAY_WATCH | element sets | perigee < 250 km, or B* > 5×10⁻³ with perigee < 300 km | perigee < 180 km critical |
| STALE_ELEMENTS | state vectors | element epoch older than 30 days | info |
| MANEUVER_CANDIDATE | consecutive element sets | Δa unexplained by the set's own drag term (> 1 km and > 3× drag), or Δi > 0.02°, or Δe·a > 2 km; sets ≥ 1 h apart | info/warning |
| NEW_OBJECT | ingest | NORAD id first seen (after warm-up) | info |
| PROPAGATION_FAILURE | propagation | SGP4 error (decayed) | info |

`AlertDeduper` is a stateful processor with a Kafka-backed store: the same `dedupeKey` is not
re-emitted within 30 minutes, so a stable formation does not produce an alert every 10 s, and the
suppression survives restarts and rebalances.

## 7. Gateway: read models and three client protocols

The gateway holds bounded materialised views: latest vector per object (16.5k entries), a ring of
720 tick stats (2 h) and 2,000 alerts. It consumes state vectors from the *latest* offset (only
"now" matters) and stats/alerts from the *earliest retained* (a fresh gateway shows recent
history). Each instance has its own consumer group because it is a cache, not a work queue —
scale out is free.

Three protocols over the same views: REST (OpenAPI at `/v3/api-docs`), GraphQL (schema in
`schema.graphqls`, field-level selection, WebSocket subscriptions for alerts and stats), and SSE
(`/api/stream/positions` pushes one compact snapshot per tick — `[id, lat, lon, alt, regime]`
arrays, ~500 kB for the whole catalogue). The dashboard uses REST for initial load and SSE for
live updates; a terminal or another service would use GraphQL. Ground tracks are computed on
demand by the propagation service (it has the element sets) and proxied — the one synchronous
service-to-service call, isolated in `PropagationClient` with a timeout and 404 mapping.

## 8. Failure modes, on purpose

| Failure | Behaviour |
|---|---|
| CelesTrak down | Serve cached payload, `fromCache=true`, `fetch_failures` metric; pipeline continues on last elements |
| Ingest restart | Fingerprints rebuilt from compacted topic; nothing republished |
| Propagation restart / second instance | Catalogue reloaded from compacted topics in < 2 s; aligned ticks make duplicate output harmless |
| Analytics restart | Streams state restored from changelog topics; dedupe store survives; in-flight tick partials lost (regenerated next tick) |
| Gateway restart | Views rebuilt from topics; clients reconnect SSE (EventSource auto-retries) |
| Kafka down | Producers buffer then fail loudly; consumers retry; nothing is lost that was acked |
| Slow analytics | Windows past grace are dropped with a WARN (`Skipping record for expired window`) — visible in logs and lag metrics, not silent |
| Cache volume not writable | Ingest keeps publishing from an in-memory cache (provider interval still enforced), WARN + `cache.write_failures` metric + health detail |
| Streams client dies (e.g. native library, state dir) | Analytics readiness DOWN, JVM exits with code 70, restart policy restarts it — a permanent fault is a visible restart loop (ADR-0008) |
| JVM out of memory | `ExitOnOutOfMemoryError` → restart; container `mem_limit` keeps one service from starving the rest |
| Catalogue still loading when a tick fires | Tick deferred (≤ 3) until element sets stop arriving, so no partial snapshot is published |

## 9. Observability

Every service exposes `/actuator/health/{liveness,readiness}` (used by Docker healthchecks and the
Kubernetes probes) and `/actuator/prometheus`. Readiness means "producing", not "listening": ingest
is DOWN after a failed run and analytics is DOWN when its Streams client is not running (ADR-0008) —
both found necessary after the first real `docker compose up`, where reproducing an empty-catalogue
stall in containers uncovered three failures hiding behind green health checks. Custom metrics: ingest published/unchanged/fetch
failures and run timer; propagation tick timer, vectors, failures, catalogue size; Kafka client
and Streams metrics come from Micrometer. `deploy/observability` ships a Prometheus scrape config
and a provisioned Grafana dashboard (tick duration, vectors/s, ingest churn, Streams throughput,
heap, gateway p95, consumer lag). Kafka UI shows topics and lag live during a demo.

## 10. Security posture (what a real deployment adds)

The demo runs PLAINTEXT Kafka on a private network and has no authentication on the gateway. The
services already take `KAFKA_SECURITY_PROTOCOL / SASL_*` from the environment (used by the OCI
Streaming overlay, which is SASL_SSL by construction). For a product: mTLS or SASL/SCRAM between
services and brokers with per-service ACLs (ingest write-only to catalogue topics, gateway
read-only), an identity-aware proxy or OAuth2 resource server in front of the gateway, rate limits
on the SSE endpoints, and egress allow-listing so only ingest can reach the internet — the same
"default deny" rule the ingest service already embodies for provider etiquette.

## 11. Deployment

`docker compose` runs the whole stack locally. One `Dockerfile` builds any service
(`--build-arg SERVICE=…`): a Node stage builds the dashboard into the gateway's static resources,
a Maven stage builds the reactor, and a slim JRE stage runs as a non-root user with a healthcheck.

OCI, two ways:

- **Single VM** (`deploy/oci/terraform`): VCN, public subnet, security list, one Ampere A1
  instance (Always-Free-eligible shape) whose cloud-init installs Docker, clones the repo and runs
  compose with the observability profile. Cheapest possible always-on demo.
- **OKE** (`deploy/k8s`): kustomize base with the four Deployments, probes, Prometheus scrape
  annotations, a single-node Kafka StatefulSet and an OCI flexible Load Balancer for the gateway.
  The `oke-oci-streaming` overlay deletes the in-cluster broker and points the services at OCI
  Streaming (Kafka-compatible, SASL_SSL) — the only change is environment variables, which is the
  point of keeping broker configuration out of code.

CI (`.github/workflows/ci.yml`) builds the dashboard, runs the full test suite, builds the four
images, and runs a smoke test that starts Kafka, runs the services offline and asserts that tick
statistics and conjunction alerts actually flow end to end.

## 12. What I would do next

In priority order: a durable alert store with acknowledgement and history (Postgres, written by a
Streams sink); a proper conjunction assessment stage that takes screening candidates and refines
time-of-closest-approach at 1 s resolution with covariance from the element-set age; owner/regime
filters on the SSE position stream to cut bandwidth; a second data source (Space-Track GP with
auth, or an ADS-B/ADS-C feed to show the integration pattern generalises); and Kotlin for the next
service to demonstrate the mixed-language build.
